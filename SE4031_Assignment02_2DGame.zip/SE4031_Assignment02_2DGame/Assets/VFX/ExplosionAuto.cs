using UnityEngine;

public class ExplosionAuto : MonoBehaviour
{
    void Start()
    {
        var ps = GetComponent<ParticleSystem>();
        if (ps != null)
        {
            ps.Play();
            Destroy(gameObject, ps.main.duration + ps.main.startLifetime.constantMax + 0.2f);
        }
        else
        {
            // fallback
            Destroy(gameObject, 1f);
        }
    }
}