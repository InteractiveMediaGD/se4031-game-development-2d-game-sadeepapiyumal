using UnityEngine;

public class Spawner : MonoBehaviour
{
    [Header("Prefabs")]
    public GameObject tunnelPrefab;
    public GameObject healthPackPrefab;
    public GameObject enemyPrefab;

    [Header("Spawn Timing")]
    public float spawnInterval = 2f;

    [Header("Spawn Position")]
    public float xAheadOfPlayer = 18f;          // how far ahead to spawn
    public float tunnelYRange = 2f;             // tunnel vertical randomness
    public float pickupEnemyYOffset = 1.2f;     // how far up/down inside gap extras can appear

    [Header("Extra Spawn Chances")]
    [Range(0f, 1f)] public float healthPackChance = 0.25f; // lowered for balance
    [Range(0f, 1f)] public float enemyChance = 0.6f;

    [Header("Extra X Offsets (prevents stacking)")]
    public float healthPackXOffset = 2f;
    public float enemyXOffset = 5f;

    [Header("Health Pack Spawn Control")]
    public float healthPackCooldown = 5f;       // minimum seconds between health packs
    [Range(0f, 1f)] public float spawnOnlyIfHealthBelow = 0.75f; // 0.75 = spawn only if HP < 75%

    private float nextHealthPackTime = 0f;

    private float timer;
    private Transform player;
    private PlayerHealth playerHealth;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player")?.transform;
        if (player != null) playerHealth = player.GetComponent<PlayerHealth>();
    }

    void Update()
    {

        if (GameManager.Instance == null || !GameManager.Instance.isGameStarted) return;
        if (GameManager.Instance.isPaused || GameManager.Instance.isGameOver) return;

        if (GameManager.Instance != null && GameManager.Instance.isGameOver) return;
        if (player == null) return;

        timer += Time.deltaTime;
        if (timer >= spawnInterval)
        {
            timer = 0f;
            SpawnSet();
        }
    }

    void SpawnSet()
    {
        if (tunnelPrefab == null) return;

        float spawnX = player.position.x + xAheadOfPlayer;
        float tunnelY = Random.Range(-tunnelYRange, tunnelYRange);

        // 1) Spawn tunnel
        GameObject tunnel = Instantiate(tunnelPrefab, new Vector3(spawnX, tunnelY, 0f), Quaternion.identity);

        // 2) Find gap center (optional but recommended)
        Transform gap = tunnel.transform.Find("GapCenter");

        // Fallback: if GapCenter not found, just use tunnel position
        Vector3 gapPos = (gap != null) ? gap.position : tunnel.transform.position;

        // --- HEALTH PACK SPAWN (balanced) ---
        // Conditions:
        //  - cooldown passed
        //  - random chance passes
        //  - (optional) only spawn if player's health is below a threshold
        bool cooldownReady = Time.time >= nextHealthPackTime;

        bool healthLowEnough = true;
        if (playerHealth != null)
        {
            float hpPercent = (float)playerHealth.currentHealth / playerHealth.maxHealth;
            healthLowEnough = hpPercent < spawnOnlyIfHealthBelow;
        }

        if (healthPackPrefab != null && cooldownReady && healthLowEnough && Random.value < healthPackChance)
        {
            float y = gapPos.y + Random.Range(-pickupEnemyYOffset, pickupEnemyYOffset);
            Vector3 pos = new Vector3(gapPos.x + healthPackXOffset, y, 0f);
            Instantiate(healthPackPrefab, pos, Quaternion.identity);

            nextHealthPackTime = Time.time + healthPackCooldown;
        }

        // --- ENEMY SPAWN ---
        if (enemyPrefab != null && Random.value < enemyChance)
        {
            float y = gapPos.y + Random.Range(-pickupEnemyYOffset, pickupEnemyYOffset);
            Vector3 pos = new Vector3(gapPos.x + enemyXOffset, y, 0f);
            Instantiate(enemyPrefab, pos, Quaternion.identity);
        }
    }
}