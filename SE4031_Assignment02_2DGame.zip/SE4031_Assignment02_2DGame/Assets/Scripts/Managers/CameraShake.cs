using System.Collections;
using UnityEngine;

public class CameraShake : MonoBehaviour
{
    [Header("Shake Settings")]
    public float defaultDuration = 0.15f;
    public float defaultStrength = 0.25f;

    Vector3 originalLocalPos;
    Coroutine shakeRoutine;

    void Awake()
    {
        originalLocalPos = transform.localPosition;
    }

    public void Shake()
    {
        Shake(defaultDuration, defaultStrength);
    }

    public void Shake(float duration, float strength)
    {
        if (shakeRoutine != null)
            StopCoroutine(shakeRoutine);

        shakeRoutine = StartCoroutine(ShakeRoutine(duration, strength));
    }

    IEnumerator ShakeRoutine(float duration, float strength)
    {
        float time = 0f;
        originalLocalPos = transform.localPosition;

        while (time < duration)
        {
            time += Time.deltaTime;

            // Random offset in a circle
            Vector2 offset = Random.insideUnitCircle * strength;
            transform.localPosition = originalLocalPos + new Vector3(offset.x, offset.y, 0f);

            yield return null;
        }

        transform.localPosition = originalLocalPos;
        shakeRoutine = null;
    }
}