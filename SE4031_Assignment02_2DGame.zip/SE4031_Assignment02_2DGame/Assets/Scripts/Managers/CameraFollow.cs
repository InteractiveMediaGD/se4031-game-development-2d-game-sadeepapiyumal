using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public float smooth = 6f;
    public float xOffset = 4f;

    void LateUpdate()
    {
        if (target == null) return;

        Vector3 pos = transform.position;
        float desiredX = target.position.x + xOffset;

        pos.x = Mathf.Lerp(pos.x, desiredX, smooth * Time.deltaTime);
        transform.position = pos;
    }
}