using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
using TMPro;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    [Header("State")]
    public bool isGameStarted = false;
    public bool isPaused = false;
    public bool isGameOver = false;

    [Header("Start UI")]
    public GameObject startUI;  // StartPanel

    [Header("Pause UI")]
    public GameObject pauseUI;  // PausePanel

    [Header("Game Over UI")]
    public GameObject gameOverUI;            // GameOverPanel
    public CanvasGroup gameOverCanvasGroup;  // CanvasGroup on GameOverPanel
    public float fadeDuration = 0.6f;

    [Header("Final Score UI")]
    public TMP_Text finalScoreText;
    public float scoreCountUpDuration = 1.0f;
    public AudioClip scoreTickSound;
    [Range(0f, 1f)] public float scoreTickVolume = 0.4f;

    [Header("Countdown")]
    public TMP_Text countdownText;           // CountdownText (TMP)
    public float countdownInterval = 1f;     // seconds between "3..2..1..GO!"
    public float countdownPopScale = 1.5f;   // how big the number pops

    [Header("Game Over Sound")]
    public AudioClip gameOverSound;
    [Range(0f, 1f)] public float gameOverVolume = 1f;

    private AudioSource audioSource;
    private Coroutine fadeRoutine;
    private Coroutine scoreCountRoutine;
    private Coroutine countdownRoutine;

    void Awake()
    {
        Instance = this;

        audioSource = GetComponent<AudioSource>();
        if (audioSource == null) audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.playOnAwake = false;
        audioSource.spatialBlend = 0f; // 2D

        // Game should NOT start automatically
        Time.timeScale = 0f;
        isGameStarted = false;
        isPaused = false;
        isGameOver = false;
    }

    void Start()
    {
        if (ScoreManager.Instance != null)
            ScoreManager.Instance.ResetScore();

        PlayerHealth ph = FindObjectOfType<PlayerHealth>();
        if (ph != null)
            ph.ResetHealth();

        if (startUI != null) startUI.SetActive(true);
        if (pauseUI != null) pauseUI.SetActive(false);

        if (gameOverUI != null) gameOverUI.SetActive(false);
        if (gameOverCanvasGroup != null)
        {
            gameOverCanvasGroup.alpha = 0f;
            gameOverCanvasGroup.interactable = false;
            gameOverCanvasGroup.blocksRaycasts = false;
        }

        if (finalScoreText != null)
            finalScoreText.text = "Final Score: 0";

        if (countdownText != null)
            countdownText.gameObject.SetActive(false);
    }

    void Update()
    {
        // Pause hotkey
        if (isGameStarted && !isGameOver && Input.GetKeyDown(KeyCode.Escape))
            TogglePause();

        // Restart hotkey (only after game over)
        if (isGameOver && Input.GetKeyDown(KeyCode.R))
            Restart();
    }

    // ---------- START ----------
    public void StartGame()
    {
        // Prevent double start clicks
        if (isGameStarted || isGameOver) return;

        if (startUI != null) startUI.SetActive(false);
        if (pauseUI != null) pauseUI.SetActive(false);

        // Run countdown then start
        if (countdownRoutine != null) StopCoroutine(countdownRoutine);
        countdownRoutine = StartCoroutine(StartCountdown());
    }

    IEnumerator StartCountdown()
    {
        isGameStarted = false;
        isPaused = false;
        isGameOver = false;

        // Freeze gameplay during countdown
        Time.timeScale = 0f;

        if (countdownText != null)
        {
            countdownText.gameObject.SetActive(true);
            countdownText.transform.localScale = Vector3.one;
        }

        string[] steps = { "3", "2", "1", "GO!" };

        for (int i = 0; i < steps.Length; i++)
        {
            if (countdownText != null)
            {
                countdownText.text = steps[i];
                countdownText.transform.localScale = Vector3.one * countdownPopScale;
            }

            float t = 0f;
            while (t < countdownInterval)
            {
                t += Time.unscaledDeltaTime;

                // Pop back to normal size over the interval
                if (countdownText != null)
                {
                    float lerp = Mathf.Clamp01(t / countdownInterval);
                    countdownText.transform.localScale =
                        Vector3.Lerp(Vector3.one * countdownPopScale, Vector3.one, lerp);
                }

                yield return null;
            }
        }

        if (countdownText != null)
            countdownText.gameObject.SetActive(false);

        // Start gameplay
        isGameStarted = true;
        Time.timeScale = 1f;
    }

    // ---------- PAUSE ----------
    public void TogglePause()
    {
        if (!isGameStarted || isGameOver) return;

        if (!isPaused) Pause();
        else Resume();
    }

    public void Pause()
    {
        isPaused = true;
        Time.timeScale = 0f;
        if (pauseUI != null) pauseUI.SetActive(true);
    }

    public void Resume()
    {
        if (isGameOver) return;

        isPaused = false;
        Time.timeScale = 1f;
        if (pauseUI != null) pauseUI.SetActive(false);
    }

    // ---------- GAME OVER ----------
    public void GameOver()
    {
        if (isGameOver) return;

        isGameOver = true;
        isPaused = false;
        isGameStarted = false;

        if (pauseUI != null) pauseUI.SetActive(false);

        if (countdownRoutine != null)
        {
            StopCoroutine(countdownRoutine);
            countdownRoutine = null;
        }
        if (countdownText != null)
            countdownText.gameObject.SetActive(false);

        if (gameOverUI != null)
            gameOverUI.SetActive(true);

        if (ScoreManager.Instance != null && finalScoreText != null)
        {
            int finalScore = ScoreManager.Instance.score;
            if (scoreCountRoutine != null) StopCoroutine(scoreCountRoutine);
            scoreCountRoutine = StartCoroutine(CountUpFinalScore(finalScore));
        }

        if (gameOverSound != null)
            audioSource.PlayOneShot(gameOverSound, gameOverVolume);

        Time.timeScale = 0f;

        if (gameOverCanvasGroup != null)
        {
            if (fadeRoutine != null) StopCoroutine(fadeRoutine);
            fadeRoutine = StartCoroutine(FadeCanvasGroupIn(gameOverCanvasGroup, fadeDuration));
        }
    }

    IEnumerator FadeCanvasGroupIn(CanvasGroup cg, float duration)
    {
        cg.alpha = 0f;
        cg.interactable = false;
        cg.blocksRaycasts = false;

        float t = 0f;
        while (t < duration)
        {
            t += Time.unscaledDeltaTime;
            cg.alpha = Mathf.Lerp(0f, 1f, t / duration);
            yield return null;
        }

        cg.alpha = 1f;
        cg.interactable = true;
        cg.blocksRaycasts = true;
    }

    IEnumerator CountUpFinalScore(int targetScore)
    {
        int lastShown = -1;
        float duration = Mathf.Max(0.1f, scoreCountUpDuration);

        float t = 0f;
        while (t < duration)
        {
            t += Time.unscaledDeltaTime;
            float progress = Mathf.Clamp01(t / duration);

            int shown = Mathf.RoundToInt(Mathf.Lerp(0, targetScore, progress));

            if (shown != lastShown)
            {
                finalScoreText.text = "Final Score: " + shown;

                if (scoreTickSound != null)
                    audioSource.PlayOneShot(scoreTickSound, scoreTickVolume);

                lastShown = shown;
            }
            yield return null;
        }

        finalScoreText.text = "Final Score: " + targetScore;
    }

    // ---------- RESTART ----------
    public void Restart()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}