using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class DamageFlash : MonoBehaviour
{
    public Image flashImage;
    public float flashDuration = 0.3f;
    public float maxAlpha = 0.4f;

    public void Flash()
    {
        StopAllCoroutines();
        StartCoroutine(FlashRoutine());
    }

    IEnumerator FlashRoutine()
    {
        Color color = flashImage.color;
        color.a = maxAlpha;
        flashImage.color = color;

        float timer = 0f;

        while (timer < flashDuration)
        {
            timer += Time.deltaTime;
            color.a = Mathf.Lerp(maxAlpha, 0, timer / flashDuration);
            flashImage.color = color;
            yield return null;
        }

        color.a = 0;
        flashImage.color = color;
    }
}