using UnityEngine;

public class ScoreZone : MonoBehaviour
{
    bool scored = false;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (scored) return;
        if (other.CompareTag("Player"))
        {
            scored = true;
            ScoreManager.Instance.AddScore(1);
        }
    }
}