using UnityEngine;

public class ObstacleDamage : MonoBehaviour
{
    public int damage = 10;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            other.GetComponent<PlayerHealth>().TakeDamage(damage);
            // Player passes through because triggers don't block movement
        }
    }
}