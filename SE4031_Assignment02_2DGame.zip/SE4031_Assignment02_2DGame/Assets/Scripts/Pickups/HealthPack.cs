using UnityEngine;

public class HealthPack : MonoBehaviour
{
    [Header("Health Settings")]
    public int healAmount = 20;

    [Header("Audio")]
    public AudioClip pickupSound;

    public float destroyOffset = -15f; // destroy after passing camera

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            PlayerHealth health = other.GetComponent<PlayerHealth>();

            if (health != null)
            {
                health.Heal(healAmount);
            }

            // Play sound at position (no AudioSource required on prefab)
            if (pickupSound != null)
            {
                AudioSource.PlayClipAtPoint(pickupSound, transform.position);
            }

            Destroy(gameObject);
        }
    }

    void Update()
    {
        if (Camera.main != null &&
            transform.position.x < Camera.main.transform.position.x + destroyOffset)
        {
            Destroy(gameObject);
        }
    }
}