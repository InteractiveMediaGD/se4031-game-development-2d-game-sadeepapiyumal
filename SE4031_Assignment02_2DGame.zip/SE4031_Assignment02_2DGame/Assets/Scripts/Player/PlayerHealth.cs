using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour
{
    public int maxHealth = 100;
    public int currentHealth;

    public Image healthFill;

    void Start()
    {
        ResetHealth();
    }

    public void ResetHealth()
    {
        currentHealth = maxHealth;
        UpdateUI();
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
        FindObjectOfType<DamageFlash>().Flash();
        UpdateUI();

        if (Camera.main != null)
        {
            CameraShake shake = Camera.main.GetComponent<CameraShake>();
            if (shake != null) shake.Shake();
        }

        if (currentHealth <= 0)
        {
            CameraShake shake = Camera.main.GetComponent<CameraShake>();
            if (shake != null)
                shake.Shake(3f, 0.3f);   // 3 seconds, intensity 0.3

            GameManager.Instance.GameOver();
        }
    }

    public void Heal(int amount)
    {
        currentHealth += amount;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
        UpdateUI();
    }

    void UpdateUI()
    {
        float hp = (float)currentHealth / maxHealth;
        healthFill.fillAmount = hp;

        // Creative Feature: health gradient color (Requirement 7)
        healthFill.color = Color.Lerp(Color.red, Color.green, hp);
    }

    /*void Update()
    {
        if (isGameOver && Input.GetKeyDown(KeyCode.R))
            Restart();
    }*/
}