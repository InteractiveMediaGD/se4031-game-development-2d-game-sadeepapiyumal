using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed = 5f;
    public float verticalSpeed = 6f;
    public float CurrentSpeed => speed;

    public float speedIncreaseRate = 0.3f;
    public float maxSpeed = 14f;

    [Header("Stay In Camera View")]
    public float verticalPadding = 0.5f;

    void Update()
    {
        // Auto forward movement
        speed += speedIncreaseRate * Time.deltaTime;
        speed = Mathf.Clamp(speed, 5f, maxSpeed);

        transform.Translate(Vector2.right * speed * Time.deltaTime);

        // Up/Down control
        float yInput = Input.GetAxisRaw("Vertical");
        transform.Translate(Vector2.up * yInput * verticalSpeed * Time.deltaTime);

        ClampToCamera();
    }

    void ClampToCamera()
    {
        if (Camera.main == null) return;

        float camHalfHeight = Camera.main.orthographicSize;
        float camCenterY = Camera.main.transform.position.y;

        float minY = camCenterY - camHalfHeight + verticalPadding;
        float maxY = camCenterY + camHalfHeight - verticalPadding;

        Vector3 pos = transform.position;
        pos.y = Mathf.Clamp(pos.y, minY, maxY);
        transform.position = pos;
    }
}