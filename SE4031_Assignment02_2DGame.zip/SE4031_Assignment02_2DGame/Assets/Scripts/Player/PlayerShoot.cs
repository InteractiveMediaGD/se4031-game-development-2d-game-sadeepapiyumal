using UnityEngine;
using UnityEngine.EventSystems;

public class PlayerShoot : MonoBehaviour
{
    public GameObject projectilePrefab;
    public float baseProjectileSpeed = 8f;
    public float lifeTime = 2f;

    public AudioClip shootSound;

    private AudioSource audioSource;
    private PlayerMovement playerMovement;
    private Collider2D playerCol;

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        playerMovement = GetComponent<PlayerMovement>();
        playerCol = GetComponent<Collider2D>();
    }

    void Update()
    {
        if (GameManager.Instance == null) return;

        // Block shooting if game not actively playing
        if (!GameManager.Instance.isGameStarted) return;
        if (GameManager.Instance.isPaused) return;
        if (GameManager.Instance.isGameOver) return;

        // Only check UI when mouse is actually clicked
        if (Input.GetMouseButtonDown(0))
        {
            // Prevent shooting when clicking UI elements
            if (EventSystem.current != null && EventSystem.current.IsPointerOverGameObject())
                return;

            Shoot();
        }
    }

    void Shoot()
    {
        if (projectilePrefab == null) return;

        // Spawn clearly in front of player
        Vector3 spawnPos = transform.position + Vector3.right * 1.2f;

        GameObject projectile = Instantiate(projectilePrefab, spawnPos, Quaternion.identity);

        // Ignore collision with player
        Collider2D projCol = projectile.GetComponent<Collider2D>();
        if (playerCol != null && projCol != null)
        {
            Physics2D.IgnoreCollision(projCol, playerCol);
        }

        // Set velocity
        Rigidbody2D rb = projectile.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            float pSpeed = (playerMovement != null) ? playerMovement.CurrentSpeed : 0f;
            rb.linearVelocity = Vector2.right * (pSpeed + baseProjectileSpeed);
        }

        Destroy(projectile, lifeTime);

        if (audioSource != null && shootSound != null)
            audioSource.PlayOneShot(shootSound);
    }
}