using UnityEngine;

public class Projectile : MonoBehaviour
{
    void Start()
    {
        Destroy(gameObject, 2f);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        // Ignore triggers that shouldn't kill the projectile
        if (other.CompareTag("Player")) return;
        if (other.CompareTag("ScoreZone")) return;
        if (other.CompareTag("HealthPack")) return;

        Destroy(gameObject);
    }
}