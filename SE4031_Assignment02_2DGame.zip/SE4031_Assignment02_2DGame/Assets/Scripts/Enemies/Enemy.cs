using UnityEngine;

public class Enemy : MonoBehaviour
{
    [Header("Combat")]
    public int damageToPlayer = 15;
    public int scoreOnKill = 5;

    [Header("VFX / SFX")]
    public GameObject explosionPrefab;     // assign EnemyExplosion prefab here
    public AudioClip explosionSound;       // assign explosion sound clip here
    [Range(0f, 1f)] public float explosionVolume = 1f;

    void OnTriggerEnter2D(Collider2D other)
    {
        // Projectile hits enemy
        if (other.CompareTag("Projectile"))
        {
            if (ScoreManager.Instance != null)
                ScoreManager.Instance.AddScore(scoreOnKill);
            else
                Debug.LogWarning("ScoreManager.Instance is NULL. Make sure ScoreManager exists in the scene.");

            // VFX
            if (explosionPrefab != null)
                Instantiate(explosionPrefab, transform.position, Quaternion.identity);

            // SFX
            if (explosionSound != null)
                AudioSource.PlayClipAtPoint(explosionSound, transform.position, explosionVolume);
            else
                Debug.LogWarning("Explosion sound is NOT assigned on the Enemy prefab.");

            Destroy(other.gameObject); // destroy projectile (optional)
            Destroy(gameObject);       // destroy enemy
            return;
        }

        // Player hits enemy
        if (other.CompareTag("Player"))
        {
            PlayerHealth ph = other.GetComponent<PlayerHealth>();
            if (ph != null)
                ph.TakeDamage(damageToPlayer);
            else
                Debug.LogWarning("PlayerHealth component missing on Player!");

            // Optional: also explode + sound when player hits enemy
            if (explosionPrefab != null)
                Instantiate(explosionPrefab, transform.position, Quaternion.identity);

            if (explosionSound != null)
                AudioSource.PlayClipAtPoint(explosionSound, transform.position, explosionVolume);

            Destroy(gameObject);
            return;
        }
    }
}